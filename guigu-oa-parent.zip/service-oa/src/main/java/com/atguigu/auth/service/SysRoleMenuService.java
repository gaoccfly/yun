package com.atguigu.auth.service;

import com.atguigu.auth.model.system.SysRoleMenu;
import com.baomidou.mybatisplus.extension.service.IService;

public interface SysRoleMenuService extends IService<SysRoleMenu> {
}
